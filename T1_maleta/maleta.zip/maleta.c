// Plantilla para maleta.c

#define _XOPEN_SOURCE 500

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <pthread.h>
#include "maleta.h"

// Defina aca las estructuras y funciones adicionales que necesite
typedef struct{
    double *w;
    double *v;
    int *z;
    int n;
    double maxW;
    int k;
    double res;
 } Args;
void *llenarMaleta(void *args){
    Args *a = (Args*) args;
    double *w = a->w;
    double *v = a->v;
    int *z = a->z;
    int n = a->n;
    double maxW = a->maxW;
    int k = a->k;
    double res = 0;
    res =llenarMaletaSec(w, v, z, n, maxW, k);
    a->res = res;
    return NULL;
}
double llenarMaletaPar(double w[], double v[], int z[], int n,
                       double maxW, int k) {
    pthread_t t[8];
    Args args[8];
    for(int i = 0; i < 8; i++){
        args[i].w = w;
        args[i].v = v;
        args[i].z = (int*)malloc(n*sizeof(int));
        for(int j = 0; j < n; j++){
            args[i].z[j] = z[j];
        }
        args[i].n = n;
        args[i].maxW = maxW;
        args[i].k = k/8;
        args[i].res = 0;
        pthread_create(&t[i], NULL, llenarMaleta, &args[i]);
    }
    for(int i = 0; i < 8; i++){
        pthread_join(t[i], NULL);
    }
    double res = 0;
    int best=0;
    for(int i = 0; i < 8; i++){
        if (res<args[i].res){
            res = args[i].res;
            best=i;
            }
    }
    for(int i=0; i<n;i++){
        z[i] = args[best].z[i];
        }
    for(int i=0 ; i<8;i++){
        free(args[i].z);
    }
    return res;
}
