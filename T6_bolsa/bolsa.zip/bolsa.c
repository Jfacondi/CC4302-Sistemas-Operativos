#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include "pss.h"
#include "bolsa.h"
#include "spinlocks.h"

// Declare aca sus variables globales
int lk = OPEN;
int cheapest = 99999999;
char *v;
char *c;
int *status = NULL;
int *m;
int vendo(int precio, char *vendedor, char *comprador){
    spinLock(&lk);
    if (precio >= cheapest && cheapest!=99999999){
        spinUnlock(&lk);
        return 0;
    }
    else{
        int estado; 
        if(status!=NULL){
        *status = 0;
        spinUnlock(m);
        status=NULL;
        }
        if(status==NULL){
        estado=0;
        status=&estado;
        v= vendedor; 
        c=comprador;
        cheapest = precio;
        } 
        int w = CLOSED;
        m = &w;
        spinUnlock(&lk);
        spinLock(&w);
        return estado;
    }
}

int compro(char *comprador, char *vendedor){
    spinLock(&lk);
    if (status==NULL){
        spinUnlock(&lk);
        return 0;
    }
    else{
        int buy = cheapest;
        strcpy(vendedor, v);
        strcpy(c,comprador); 
        *status=1;
        cheapest=99999999;
        spinUnlock(m);
        v=NULL;
        c=NULL;
        status=NULL;
        spinUnlock(&lk);
        return buy;
    }
}
