#define _XOPEN_SOURCE 500

#include "nthread-impl.h"

#include "rwlock.h"

struct rwlock {
 NthQueue *rq;
 NthQueue *wq;
 int r;
 int w;
};

nRWLock *nMakeRWLock() {
  nRWLock *rwl = (nRWLock *)nMalloc(sizeof(nRWLock));
  rwl->rq = nth_makeQueue();
  rwl->wq = nth_makeQueue();
  rwl->r = 0;
  rwl->w = 0;
  return rwl;
}

void nDestroyRWLock(nRWLock *rwl) {
  nth_destroyQueue(rwl->rq);
  nth_destroyQueue(rwl->wq);
  free(rwl);
}

int nEnterRead(nRWLock *rwl, int timeout) {
  START_CRITICAL
  if(rwl->w == 0 && nth_emptyQueue(rwl->wq)) {
    rwl->r++;
  }
  else { 
    nThread thisth = nSelf();
  nth_putBack(rwl->rq, thisth);
  suspend(WAIT_RWLOCK);
  schedule();

  }
  END_CRITICAL
  return 1;
}

int nEnterWrite(nRWLock *rwl, int timeout) {
  START_CRITICAL
  if(rwl->r == 0 && rwl->w == 0) {
    rwl->w++;
  }
  else {
    nThread thisth = nSelf();
    nth_putBack(rwl->wq, thisth);
    suspend(WAIT_RWLOCK);
    schedule();
  }
  END_CRITICAL
  return 1;
}

void nExitRead(nRWLock *rwl) {
  START_CRITICAL
  rwl->r--;
  if(rwl->r == 0 && !nth_emptyQueue(rwl->wq)) {
    nThread w= nth_getFront(rwl->wq);
    rwl->w++;
    setReady(w);
    schedule();
  }
  END_CRITICAL
}

void nExitWrite(nRWLock *rwl) {
  START_CRITICAL
  rwl->w--;
  if(!nth_emptyQueue(rwl->rq)) {
    while (!nth_emptyQueue(rwl->rq))
    {
      nThread r = nth_getFront(rwl->rq);
      rwl->r++;
      setReady(r);
      schedule();
    }
    
  }
  else if(!nth_emptyQueue(rwl->wq)) {
    nThread w = nth_getFront(rwl->wq);
    rwl->w++;
    setReady(w);
    schedule();
  }
  END_CRITICAL
}
