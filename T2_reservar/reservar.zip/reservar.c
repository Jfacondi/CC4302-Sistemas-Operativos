#define _XOPEN_SOURCE 500

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "reservar.h"

// Defina aca las variables globales y funciones auxiliares que necesite
int estacionamientos[10];
int maxEstacionamientosSeguidos = 10;
int ticket_dist = 0, display = 0;
pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t c = PTHREAD_COND_INITIALIZER;
void checkEstacionamientos() {
    int max = 0;
    for (int i = 0; i < 10; i++) {
        if (estacionamientos[i] == 0) {
            int count = 0;
            for (int j = i; j < 10; j++) {
                if (estacionamientos[j] == 0) {
                    count++;
                } else {
                    break;
                }
            }
            if (count > max) {
                max = count;
            }
        }
    }
    maxEstacionamientosSeguidos = max;
}

void initReservar() {
  // empty
}

void cleanReservar() {
  // empty
}


int reservar(int k) {
    pthread_mutex_lock(&m);
    int my_num = ticket_dist++;
    while (maxEstacionamientosSeguidos < k || my_num!=display) {
        pthread_cond_wait(&c, &m);
    }
    for (int i = 0; i <= 10 - k; i++) {
        int j = i;
        int bandera = 0;
        for (int l = 0; l < k; l++) {
            if (estacionamientos[j] != 0) {
                bandera = 1;
                break;
            }
            j++;
        }
        if (bandera == 1) {
            continue;
        } else {
            for (int l = 0; l < k; l++) {
                estacionamientos[i + l] = 1;
            }
            checkEstacionamientos();
            display++;
            pthread_cond_broadcast(&c);
            pthread_mutex_unlock(&m);
            return i;
        }
    }
    pthread_mutex_unlock(&m);
    return -1;
}

void liberar(int e, int k) {
    pthread_mutex_lock(&m);
    if (e >= 0 && e + k <= 10) { 
        for (int i = e; i < e + k; i++) {
            if (estacionamientos[i] == 1) {
                estacionamientos[i] = 0;
            }
        }
        checkEstacionamientos();
    }
    pthread_cond_broadcast(&c);
    pthread_mutex_unlock(&m);
}
